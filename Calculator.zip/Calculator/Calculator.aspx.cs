﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Calculator : System.Web.UI.Page
{
    double digit;
    double digittwo;

    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        if (Double.TryParse(num1.Text, out digit))
        {
            if (Double.TryParse(num2.Text, out digittwo))
            {
                output.Text = (digit + digittwo).ToString();
                error1.Text = " ";
                error2.Text = "";
            }
            else
            {
                error2.Text = "Please input a number for the Second textbox";
            }
        }
        else
        {
            error1.Text = "Please input a number for the first textbox";
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if (Double.TryParse(num1.Text, out digit))
        {
            if (Double.TryParse(num2.Text, out digittwo))
            {
                error1.Text = " ";
                error2.Text = " ";
                output.Text = (digit - digittwo).ToString();
            }
            else
            {
                error2.Text = "Please input a number for the Second textbox";
            }
        }
        else
        {
            error1.Text = "Please input a number for the first textbox";
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        if (Double.TryParse(num1.Text, out digit))
        {
            if (Double.TryParse(num2.Text, out digittwo))
            {
                error1.Text = " ";
                error2.Text = " ";
                output.Text = (digit * digittwo).ToString();
            }
            else
            {
                error2.Text = "Please input a number for the Second textbox";
            }
        }
        else
        {
            error1.Text = "Please input a number for the first textbox";
        }
    }


    protected void Button4_Click(object sender, EventArgs e)
    {
        
        if (Double.TryParse(num1.Text, out digit))
        {
                if (Double.TryParse(num2.Text, out digittwo))
                {
                error1.Text = " ";
                error2.Text = "";
                output.Text = (digit / digittwo).ToString();
                }
                    else
                    {
                        error2.Text = "Please input a number for the Second textbox";
                    }
        }
            else
            {
                error1.Text ="Please input a number for the first textbox";
            }

        }

    protected void reset_Click(object sender, EventArgs e)
    {
        num1.Text = "";
        num2.Text = "";
        output.Text = "";
        error1.Text = "";
        error2.Text = "";

    }
}
